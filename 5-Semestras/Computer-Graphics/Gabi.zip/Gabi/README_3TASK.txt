Labas, 
su trecia uzduotim yra taip:

Ten pagal studento numeri reikia atsiskaityt varianta,
tai man reikejo ta tora (spurga), bet as tiesiog sita kugi parodziau nieko nesakes :D

Dar pasakiau kad siunciau i pasta jam pries savaite ir negalejau ateit tai neateme savaites :D
tai jei turi drasos gali sita isaut :D

toliau per daug apie koda nepapasakosiu, bet kazkodel man paleidus html neuzdeda 
mano sachmatines lentos spalvos, bet per atomo preview rodo, nezinau, prisegiau [proof.png]
kur ten parodziau kaip rodo

ai ir pasikeisk ta sachmatine lenta i bet kokia kita, ir ten pavadinsi taip pat

is klausimu puses jis nieko neklaus,

nebent kaip generuoji taskus, tai tu tiesiog paziurek koda kur yra generate points
ten ima random xyz ir tada tikrina ar patenka i nelygybe, jei patenka kuria vektoriu

ir man biski nueme todel kad ten negraziai tos sienos atrodo

daugiau sekmes ziurint, jeigu mane darbe pasigausi su kompu, galesiu tada ir isamiau paaiskint, 
o siaip parasyk :)
