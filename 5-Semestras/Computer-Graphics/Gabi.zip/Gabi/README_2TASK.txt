Labas,

su antra uzduotim yra taip:

realiai kiekviena is figuru reikejo susimodeliuot paciam.
jeigu pasiziuresi tai mano ir tautvio variante skiriasi tik karalius, tai siulau ir tau bent viena
figura pasibandyt susimodeliuot.

kad tai padaryt, susirast reikia figura 2d internete paveiksliuku
parsisiust, pavadinsi kaip ten yra model_image

tada atsidarysi ta model_image html per browseri, paspausi ant to ekraniuko, paspausi space atsiras paveiksliukas, 
sudeliosi taskus kur reikia, ir man atrodo kad reikia simetriskai, (nes manes poto destytojas klause kodel is abieju pusiu taskus dejau)
todel is vienos puses tik taskus dek, tada paspausi enter ir paspaudus f12, nuejus iki konsoles rasi taskus kuriuos reiks ten kode ipastint
kuo daugiau tasku, tuo geriau atrodys figura :D

tai destytojas klaus kokia naudojai programa modeliuot, tada gali sakyt jam kad jo duota pavyzdi sita curve edita, nuims gal -0.1 uz tai :D

o daugiau neprisimenu ka pasakyt, tai jei ka klausk :D